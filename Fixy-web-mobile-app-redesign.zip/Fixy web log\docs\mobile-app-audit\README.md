# Fixy — Rediseño mobile app

Fecha de QA: 27 de julio de 2026

## Alcance implementado

- Sistema visual compartido en `css/app-mobile.css`.
- App shell y comportamiento compartido en `js/app-shell.js`.
- Integración del sistema en los 18 HTML del proyecto.
- Navegación móvil de pantalla completa con subnivel de soluciones.
- Bloqueo de scroll, foco contenido, cierre por botón, fondo y Escape, y restauración del foco.
- Barra superior compacta con estado al hacer scroll y respeto de safe areas.
- Superficies conectadas, hero oscuro, jerarquía tipográfica, controles táctiles y feedback pressed/focus.
- Formularios de una columna, controles de 48–52 px, texto de 16 px y atributos de teclado/autocomplete.
- FAQ y acordeones táctiles.
- Footer móvil como pantalla final con categorías expandibles.
- CTA móvil contextual: se oculta cuando su acción, el contacto o el footer están visibles.
- Tratamiento específico para Home, servicios, Tecnología, Recursos, artículos y Developers.
- Reducción de movimiento mediante `prefers-reduced-motion`.

## Preservación de contenido

Comparación automatizada contra `Fixy web log zip.zip`:

- HTML comparados: 18
- HTML con texto visible sin cambios: 18
- HTML con diferencias de texto visible: 0

Se preservaron IDs, metadatos, datos estructurados, canonicals, rutas, `data-ev` y scripts funcionales existentes.

## QA funcional

Verificado en navegador:

- Menú móvil: apertura, subnivel, cierre con Escape, scroll lock y restauración del foco.
- Constructor: selección inicial, habilitación y avance al paso siguiente.
- Cobertura: cambio entre “Cobertura regional” y “Todo el país”.
- Métricas: activación por entrada en viewport y llegada a sus valores finales.
- FAQ: apertura y sincronización de `aria-expanded`.
- Footer: apertura/cierre por Space y Enter.
- CTA fijo: oculto junto a acciones equivalentes y footer; visible durante el recorrido.
- Campos: fuente mínima de 16 px y altura mínima de 48 px.
- Rutas y assets internos comprobados: 30/30.
- Errores y advertencias de consola: 0.

## Matriz responsive

Home, FixyFull, Tecnología, Recursos y Developers se verificaron en:

- 320 × 568
- 360 × 800
- 375 × 812
- 390 × 844
- 412 × 915
- 430 × 932
- 768 × 1024
- 1024 × 768
- 1440 × 900

Resultado: 45/45 verificaciones sin overflow horizontal, imágenes rotas ni contenido principal ausente.

Las 18 rutas principales también se verificaron a 390 × 844.

## Evidencia

La carpeta `screenshots/` incluye:

- Home: 320 × 568, 390 × 844, 768 × 1024 y 1440 × 900.
- Menú móvil: 390 × 844.
- FixyFull: 390 × 844 y 1440 × 900.
- Tecnología: 390 × 844.
- Recursos: 390 × 844.
- Developers: 390 × 844.

## Incidencias detectadas y corregidas

- Overflow real a 320 px causado por un ancho mínimo combinado con la barra de scroll.
- Imagen decorativa de Home superpuesta al título a 320 px.
- Botón del menú reducido por flex-shrink en Developers.
- CTA fijo duplicando o cubriendo una acción visible en el hero.
- Botón secundario con contraste insuficiente sobre el hero de Tecnología.
- Texto heredado con contraste insuficiente dentro de tarjetas claras sobre heroes oscuros.
- Targets táctiles pequeños en enlaces de soluciones y footer.
- Estado inconsistente de scroll lock al cerrar Home con Escape por convivencia con la lógica previa.

## Limitaciones reales

- No están incluidos los archivos de Filson Pro:
  - `FilsonPro-Regular.woff2`
  - `FilsonPro-Medium.woff2`
  - `FilsonPro-Bold.woff2`
  - `FilsonPro-Heavy.woff2`
- El sitio conserva el fallback de sistema ya previsto.
- Los formularios mantienen el comportamiento e integraciones existentes; no se enviaron datos reales durante QA.
- El proyecto no incluye repositorio Git, por lo que la validación de contenido se realizó contra el ZIP original en lugar de `git diff`.
