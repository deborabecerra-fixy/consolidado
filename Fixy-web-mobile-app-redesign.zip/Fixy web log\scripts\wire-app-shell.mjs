import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const root = process.cwd();
const htmlFiles = [];

async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name === 'docs' || entry.name === 'scripts') continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (entry.name.endsWith('.html')) htmlFiles.push(full);
  }
}

await walk(root);
let changed = 0;
for (const file of htmlFiles) {
  let html = await readFile(file, 'utf8');
  if (!html.includes('/css/app-mobile.css')) {
    html = html.replace('</head>', '<link rel="stylesheet" href="/css/app-mobile.css">\n<script src="/js/app-shell.js" defer></script>\n</head>');
    await writeFile(file, html, 'utf8');
    changed++;
  }
}
console.log(JSON.stringify({ scanned: htmlFiles.length, changed }));
